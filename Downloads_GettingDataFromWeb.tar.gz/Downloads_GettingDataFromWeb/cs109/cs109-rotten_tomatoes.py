# -*- coding: utf-8 -*-
"""
Created on Tue Jun 16 09:41:40 2015

@author: pcba
"""

import json

import requests
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# set some pandas options related to output display
pd.set_option('display.width', 500)
pd.set_option('display.max_columns', 30)

# set some nicer defaults for matplotlib
from matplotlib import rcParams

#these colors come from colorbrewer2.org. Each is an RGB triplet
dark2_colors = [(0.10588235294117647, 0.6196078431372549, 0.4666666666666667),
                (0.8509803921568627, 0.37254901960784315, 0.00784313725490196),
                (0.4588235294117647, 0.4392156862745098, 0.7019607843137254),
                (0.9058823529411765, 0.1607843137254902, 0.5411764705882353),
                (0.4, 0.6509803921568628, 0.11764705882352941),
                (0.9019607843137255, 0.6705882352941176, 0.00784313725490196),
                (0.6509803921568628, 0.4627450980392157, 0.11372549019607843),
                (0.4, 0.4, 0.4)]

# This is how you set global matplotlib defaults
# See http://matplotlib.org/users/customizing.html?highlight=matplotlibrc
rcParams['figure.figsize'] = (10, 6)
rcParams['figure.dpi'] = 150
rcParams['axes.color_cycle'] = dark2_colors
rcParams['lines.linewidth'] = 2
rcParams['axes.grid'] = False
rcParams['axes.facecolor'] = 'white'
rcParams['font.size'] = 14
rcParams['patch.edgecolor'] = 'none'


def remove_border(axes=None, top=False, right=False, left=True, bottom=True):
    """
    Minimize chartjunk by stripping out unnecessary plot borders and axis ticks
    
    The top/right/left/bottom keywords toggle whether the corresponding plot border is drawn
    """
    ax = axes or plt.gca()
    ax.spines['top'].set_visible(top)
    ax.spines['right'].set_visible(right)
    ax.spines['left'].set_visible(left)
    ax.spines['bottom'].set_visible(bottom)
    
    #turn off all ticks
    ax.yaxis.set_ticks_position('none')
    ax.xaxis.set_ticks_position('none')
    
    #now re-enable visibles
    if top:
        ax.xaxis.tick_top()
    if bottom:
        ax.xaxis.tick_bottom()
    if left:
        ax.yaxis.tick_left()
    if right:
        ax.yaxis.tick_right()
        

# The following is my API key for the Rotten Tomatoes site. We can all use it tonight, but
# go get your own after today if you want to keep going on this.

api_key = '2z49tsyxacf2m8r3jmcy4b7v'
movie_id = '770672122'  # toy story 3

# Build up the URL using the % "string formatting operator". This is a somewhat older
# string formatting technique and is covered starting on page 135 of PCfB. The
# placeholders commonly used are %s for string, %d for int digits, %f for floats.
# The newer (Python 2.6+) method uses string.format() where the string contains various
# placeholders embedded and format contains the things to get formatted. A nice intro
# to the newer method can be found at http://infohost.nmt.edu/tcc/help/pubs/python/web/new-str-format.html.
# Anyhoo, ....

url = 'http://api.rottentomatoes.com/api/public/v1.0/movies/%s/reviews.json' % movie_id

#these are "get parameters"
options = {'review_type': 'top_critic', 'page_limit': 20, 'page': 1, 'apikey': api_key}
data = requests.get(url, params=options).text
data = json.loads(data)  # load a json string into a collection of lists and dicts


print (json.dumps(data['reviews'], indent=2) ) # dump an object into a json string
