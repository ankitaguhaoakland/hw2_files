# Read me file for Mike Jacobs NYT API project#
MIS680
Final Project - NY Times API Exploration
Mike Jacobs

My main project file consists of a python notebook:
NYT_API_exploration.ipynb

There is also a csv:
nytimes06262016

The csv contains the article data retrieved from the API.
There is code in the notebook to load the csv into a dataframe.
The code to call the API is commented out (after an initial test API call using a package)

The only other special instructions are concerning the NLTK package.
I included the NLTK data file that was created as I downloaded content, but:
If any of the functions don't work, the downloader code in the python notebook can be used to download required files.
There are comments explaining which files to download.

