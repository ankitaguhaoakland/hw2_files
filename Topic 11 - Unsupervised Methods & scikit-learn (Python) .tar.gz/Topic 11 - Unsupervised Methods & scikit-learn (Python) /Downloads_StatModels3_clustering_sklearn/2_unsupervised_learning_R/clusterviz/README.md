Hack #1 - clusterviz.ipynb
--------------------------

I quickly hacked together an IPython notebook that would allow me
to visualize each step of K-means clustering. I got the base K-means
code from the book Data Science from Scratch by Joel Grus. The code
is freely available from the following site:

https://github.com/joelgrus/data-science-from-scratch

I made some modifications to allow "single stepping" of the K-means
algorithm. I used scikit-learn to generate random "blobs" of data
for use in clustering algorithm testing. Matplotlib was used to 
plot the cluster centers and cluster members at each step of the
algorithm. It was a fun little exercise and there's tons of room
for improvement. Doing things like this is a great way to learn
more about Python programming and data science.

Hack #2 - clustercolors.ipynb
------------------------------

This example is also from the book listed above and shows how
cluster analysis can be used to modify an image. Cool example.


-rw-rw-r-- 1 mis447 mis447 30823 Jun 14 23:21 Blackburnian_KevinBolton.JPG
-rw-rw-r-- 1 mis447 mis447  4844 Jun 14 23:47 clustercolors.ipynb
-rw-rw-r-- 1 mis447 mis447  7793 Jun 14 23:01 clustering.py
-rw-rw-r-- 1 mis447 mis447 48366 Jun 14 22:52 clusterviz.ipynb
-rw-rw-r-- 1 mis447 mis447  3566 Apr 10 15:21 linear_algebra.py
-rw-rw-r-- 1 mis447 mis447   745 Jun 14 23:06 README.md
