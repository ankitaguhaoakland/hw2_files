Cloning an existing git repository
==================================

Do this to get an existing git repo so that you can:

* work on it,
* modify it for your uses,
* get the repo onto some computer

https://git-scm.com/book/en/v1/Git-Basics-Getting-a-Git-Repository

Cloning one of my repos
=======================

At my GitHub site there's a page listing the repos:

https://github.com/misken?tab=repositories

Select the **rfordatascience** repo.

This is a repo I created to manage the documents I created while
working my way through HW's "R for Data Science Book". I try the
examples and exercises, make notes to myself, and try to learn a
bunch of useful new R techniques and tools. You might find this repo
useful and then you can build on it for yourself.

Use the big green Clone button to copy the repo URL to the clipboard.

Let's make a subfolder within /Documents called repo_dloads. Then
cd into this subfolder.

    cd repo_dloads

Now, we'll clone the rfordatascience repo into this subfolder.
    
    git clone https://github.com/misken/rfordatascience.git
    cd rfordatascience
    ls -l -a
    
Voila! You've not got your own repo based on mine and can do with it
what you wish.

    

