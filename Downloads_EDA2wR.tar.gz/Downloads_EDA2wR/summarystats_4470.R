# See Chapter 8 in RforE for a nice introduction to creating basic
# functions in R. Here's two versions of a Hello World level function
# that will be enough to get us going.

say.hello <- function()
{
  print("Hello, World!")
}

# Let's run the above function. What happens?
# Now let's USE the above function from the command line.

# A few things to note about this function:
#   - it's perfectly fine to use the '.' as part of a function name
#   - this function takes NO input arguments
#   - this function can only print "Hello, World!"
#   - functions are objects. If you type say.hello at the command line
#     you'll just get the definition of the function spit back at you
#   - to actually use the function, you need to type say.hello() at command line
#   - you can capture the return value of this function in a variable just as
#     you can with any other built in R function.
#   - speaking of return values, there is no return() command. By default, R
#     returns the result of the last line of code in the function. Often it's
#     better practice to explicitly use the return() command. See p103 in RforE.

# It would be more useful if we could say Hello to people of our choice.
# See Section 8.2 in RforE.

say.helloto <- function(name)
{
  print(sprintf("Hello, %s", name))
}

# sprintf() is an old classic function from the C programming language. It stands for
# "string print formatted". Anything with a % is a placeholder AND a format specification.
# The things after the comma are the variables to print. So, you'll have one format specifier
# per variable. You might have guessed that the s in %s stands for string. The C style 
# format specification language is widely used (Google sprintf and you'll see just how widely used it is)
# and well worth knowing. With it, you can
# do things like controlling the width and number of digits to display after the decimal
# point when displaying numeric data. That will come in handy down below. 

# A good intro to sprintf for R users is at: http://www.inside-r.org/r-doc/base/sprintf

# Ok, now we know enough to write a simple summary stats function that lets
# us pass in ????? and simply prints out a bunch of summary stats. Start
# by just reporting out the min, mean, and max. 

### Let's create summarystats_v1() function that prints out min, mean and max of some variable.


summarystats_v1 <- function(data){
  print(mean(data, na.rm = TRUE))
}







#BTW, what does that Source on Save checkbox mean?

# So, summarystats_v1 works but has a few shortcomings:
# - there are no labels to tell you what the numbers are
# - it only outputs the min, mean and max
#
# I'm sure you can extend this to include labels and more stats. 
# I'm sure you can extend this to include labels and more stats. That will be
# part of a future assignment.

### You create summarystats_v2() function that implements the extensions just mentioned.
# BTW, check out the "Comment/Uncomment Lines" feature in the Code menu.

# summarystats_v2 <- 
# {
#   
#   
# }
