from .sgd_separator import plot_sgd_separator
from .linear_regression import plot_linear_regression
from .ML_flow_chart import plot_supervised_chart, plot_unsupervised_chart
from .helpers import plot_iris_knn
