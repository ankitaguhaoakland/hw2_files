StatsModels2 - Classification with R

Start with IntroDataScience_notes.Rmd

Then we'll work through the following examples in this order. There is
a folder for each.

* Intro to classification problems using the Kaggle HR dataset
* Logistic regression - binary classification using a variant of linear
regression. Data from the American Community Survey.
* k-Nearest Neighbor - a very simple, model free, classification 
technique. Will be our first look at the famous Iris dataset and we'll
also see another plotting package called **ggviz**.
* Titanic challenge - this is a famous Kaggle practice competition for
those new to data science.

