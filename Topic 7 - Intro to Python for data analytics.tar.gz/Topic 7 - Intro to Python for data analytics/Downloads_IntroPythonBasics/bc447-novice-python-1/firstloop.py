# -*- coding: utf-8 -*-
"""
Created on Fri May 30 14:15:05 2014

@author: pcba
"""

length = 0
for vowel in 'aeiou':
    length = length + 1
print 'There are', length, 'vowels'